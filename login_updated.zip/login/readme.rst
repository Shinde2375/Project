Admin Login : email = admin@gmail.com
                Password = 12345


User Login : email = user@gmail.com 
            Password = 1234

            

            ps: after unziping file plz put inner login folder in XAMPP-> htdocs.
            to avoid any error.