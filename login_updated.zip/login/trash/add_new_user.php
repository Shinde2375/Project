<?php
include "../user/connection.php";
?>




<?php
include "header.php";
include "../user/connection.php";
?>
<!--main-container-part-->
<div id="content">
  <!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"><a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
        Add New User</a></div>
  </div>
  <!--End-breadcrumbs-->

  <!--Action boxes-->
  <div class="container-fluid">

    <div class="row-fluid">
      <div class="span11">
        <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
          <div class="widget-box">
            <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
              <h5>Add New User</h5>
            </div>
            <div class="widget-content nopadding">
              <form name="form1" action="" method="post" class="form-horizontal">
                <div class="control-group">

                  <label class="control-label">First Name :</label>
                  <div class="controls">
                    <input type="text" class="span11" placeholder="First name" name="firstname" />
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label">Last Name :</label>
                  <div class="controls">
                    <input type="text" class="span11" placeholder="Last name" name="lastname" />
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label">User Name :</label>
                  <div class="controls">
                    <input type="text" class="span11" placeholder="username" name="username" />
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label">Password :</label>
                  <div class="controls">
                    <input type="password" class="span11" placeholder="Enter Password" name="password" />
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label">Select Role :</label>
                  <div class="controls">
                    <!-- <input type="text" class="span11" placeholder="Enter user/admin" name="role" /> -->
                    <select name="role" class="span11">
                      <option>user</option>
                      <option>admin</option>
                    </select>

                  </div>
                </div>

                <div class="alert alert-danger" id="error" style="display: none">
                  This User name already exist ! please try another.
                </div>

                <div class="form-actions">
                  <button type="submit" name="submit1" class="btn btn-success">Save</button>
                </div>



                <div class="alert alert-sucess" id="sucess" style="display:none">
                  Record inserted sucessfully!.
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>




  <div class="widget-content nopadding">
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>id</th>
          <th>User Firstname</th>
          <th>User Lastname</th>
          <th>Username</th>
          <th>Password Size</th>
          <th>Role</th>
          <th>Status</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
        <?php

        $res = mysqli_query($link, "SELECT * from user_registration");
        while ($row = mysqli_fetch_array($res)) { ?>
          <tr>
            <td style="text-align: center;">
              <?php echo $row["id"]; ?>
            </td>
            <td style="text-align: center;">
              <?php echo $row["firstname"]; ?>
            </td>
            <td style="text-align: center;">
              <?php echo $row["lastname"]; ?>
            </td>
            <td style="text-align: center;">
              <?php echo $row["username"]; ?>
            </td>
            <td style="text-align: center;">
              <?php echo $row["password"]; ?>
            </td>
            <td style="text-align: center;">
              <?php echo $row["role"]; ?>
            </td>
            <td style="text-align: center;">
              <?php echo $row["status"]; ?>
            </td>


            <td style="text-align: center   ;">
              <a href="add_new_user.php?rs=<?php echo $row['id']; ?>">
                Delete
            </td>

          </tr>
          <?php

        }
        ?>
      </tbody>
    </table>
  </div>



  <?php
  if (isset($_POST["submit1"])) {

    $count = 0;
    $res = mysqli_query($link, "SELECT * FROM user_registration  WHERE firstname =' $_POST[firstname]' && lastname= '$_POST[lastname]' && username ='$_POST[username]' && password ='$_POST[password]' && role ='$_POST[role]' ");
    $count = mysqli_num_rows($res);

    if ($count > 0) {
      ?>
      <script>
        document.getElementById('success').style.display = 'none';
        document.getElementById('error').style.display = 'block';
      </script>"

      <?php

    } else {
      $res = mysqli_query($link, "insert into  user_registration values (NULL, '$_POST[firstname]','$_POST[lastname]' , '$_POST[username]' ,'$_POST[password]' ,'$_POST[role]' ,'active' ) ") or die(mysqli_error($link));

      ?>
      <script type="text/javascript">

        document.getElementById("sucess").style.display = "block";
        document.getElementById("error").style.display = "none";
        setTimeout(function () {
          window.location.href = window.location.href;
        }, 3000);

      </script>


      <?php

    }


  }