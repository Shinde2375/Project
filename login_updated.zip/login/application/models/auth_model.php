<?php

class auth_model extends CI_Model
{


    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function register_user()
    {

        $password = $this->input->post('password');
        $con_password = $this->input->post('con_password');


        if ($password != $con_password) {
            $this->session->set_flashdata('wrong', 'The password not equal with confirmation!');
            redirect('Auth/register');
        } else {
            $data = array(
                "name" => $this->input->post('name'),
                "email" => $this->input->post('email'),
                "password" => $password
            );

            $this->db->insert('users', $data);
            $this->session->set_flashdata('success', 'You are registered please login');
            redirect('Auth/');

        }
    }

    public function login_user()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $query = $this->db->get('users');
        $find_user = $query->num_rows($query);

        if ($find_user > 0) {

            $this->session->set_userdata('name', $query->row()->name);
            $this->session->set_userdata('email', $query->row()->email);
            $this->session->set_userdata('log', 'logged');
            $this->session->set_flashdata('success', 'You are logged');
            redirect('Auth/main');
        } else {
            $this->session->set_flashdata('warning', 'Incorrect Authentication!!!');
            redirect('Auth/');
        }
    }
    public function get_product()
    {

        $query = $this->db->get('products');
        return $query->result();
    }
    public function get_cart()
    {

        $query = $this->db->get('emp_cart');
        return $query->result();
    }
    public function insert_product()
    {
        $data = array(
            "company_name" => $this->input->post('company_name'),
            "product_name" => $this->input->post('product_name'),
            "price" => $this->input->post('price')
        );


        $this->db->insert('products', $data);
        redirect(base_url('Auth/add_products'));

    }
    public function login_admin()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $query = $this->db->get('admin_registration');
        $find_user = $query->num_rows($query);

        if ($find_user > 0) {
            $this->session->set_userdata('name', $query->row()->name);
            $this->session->set_userdata('email', $query->row()->email);
            $this->session->set_userdata('logd', 'loggeds');
            $this->session->set_flashdata('success', 'You are logged');
            redirect('Auth/admin');
        } else {
            $this->session->set_flashdata('warning', 'Incorrect Authentication!!!');
            redirect('Auth/admin');
        }
    }

    public function editproduct($id)
    {
        $query = $this->db->get_where('products', ['id' => $id]);
        return $query->row();
    }
    public function addproduct($id)
    {
        $query = $this->db->get_where('products', ['id' => $id]);
        return $query->row();
    }
    public function update_product($data, $id)
    {
        return $this->db->update('products', $data, ['id' => $id]);
    }
    public function add_product($data, $id)
    {
        return $this->db->insert('emp_cart', $data, ['id' => $id]);
    }


    public function delete_product($id)
    {
        return $this->db->delete('products', ['id' => $id]);

    }
    public function delete_cart($id)
    {
        return $this->db->delete('emp_cart', ['id' => $id]);

    }
    public function get_totalval()
    {

        $this->db->select_sum('price');
        $query = $this->db->get('emp_cart');
        return $query->row()->price;
    }

}

?>