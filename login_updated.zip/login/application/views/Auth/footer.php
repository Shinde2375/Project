<!--Footer-part-->
<div class="row-fluid">
    <div id="footer" class="span12" style="color:white"> Designed And Developed By: Vishal Shinde</div>
</div>
<!--end-Footer-part-->
<script src="<?php echo site_url(); ?>assets/resources/js/excanvas.min.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/jquery.min.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/jquery.ui.custom.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/bootstrap.min.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/jquery.flot.min.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/jquery.flot.resize.min.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/jquery.peity.min.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/fullcalendar.min.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/matrix.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/matrix.dashboard.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/jquery.gritter.min.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/matrix.interface.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/matrix.chat.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/jquery.validate.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/matrix.form_validation.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/jquery.wizard.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/jquery.uniform.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/select2.min.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/matrix.popover.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/jquery.dataTables.min.js"></script>
<script src="<?php echo site_url(); ?>assets/resources/js/matrix.tables.js"></script>

<script type="text/javascript">


    <?php if ($this->session->flashdata('success')) { ?>
        toastr.success("<?php echo $this->session->flashdata('success'); ?>");
    <?php } else if ($this->session->flashdata('wrong')) { ?>
            toastr.error("<?php echo $this->session->flashdata('wrong'); ?>");
    <?php } else if ($this->session->flashdata('warning')) { ?>
                toastr.warning("<?php echo $this->session->flashdata('warning'); ?>");
    <?php } else if ($this->session->flashdata('info')) { ?>
                    toastr.info("<?php echo $this->session->flashdata('info'); ?>");
    <?php } ?>
    <?php
    $this->session->unset_userdata('success'); ?>

    <?php
    $this->session->unset_userdata('wrong'); ?>

</script>
</body>

</html>