<!--  -->


<?php
include 'header.php';
?>
<!--main-container-part-->
<div id="content">
	<!--breadcrumbs-->
	<div id="content-header">
		<div id="breadcrumb"><a href="<?php site_url() ?>main" title="Go to Home" class="tip-bottom"><i
					class="icon-home"></i>
				Home</a></div>
	</div>
	<!--End-breadcrumbs-->

	<!--Action boxes-->
	<div class="container-fluid">


		<div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
			<a href="<?php site_url() ?>product_sales">
				<h1>Buy Products</h1>
			</a>
		</div>
		<div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
			<a href="<?php site_url() ?>admin_index">
				<h1>Go To Admin</h1>
			</a>

		</div>


	</div>
</div>


<!--end-main-container-part-->
<!--Footer-part-->

<?php
include 'footer.php';
?>