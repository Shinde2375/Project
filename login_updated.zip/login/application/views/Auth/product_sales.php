<?php
include 'header.php';
?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div id="content">
    <form name="form1" action="" method="post" class="form-horizontal nopadding">
        <!--breadcrumbs-->
        <div id="content-header">
            <div id="breadcrumb"><a href="" class="tip-bottom"><i class="icon-home"></i>
                    <?php echo $this->session->userdata('name'); ?>'s Cart
                </a></div>
        </div>

        <div class="container-fluid">

            <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
                <!-- <div class="span12"> -->
                <div class="widget-box">
                    <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                        <h5>Buy a Products</h5>
                    </div>

                    <div class="widget-content nopadding">


                        <div class=" span3">
                            <br>

                            <div>
                                <label>Full Name</label>
                                <input type="text" class="span12" name="full_name" required>
                            </div>
                        </div>

                        <div class="span3">
                            <br>

                            <div>
                                <label>Bill Type</label>
                                <select class="span12" name="bill_type_header">
                                    <option>Cash</option>
                                    <option>Debit</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


            <!-- new row-->



            <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
                <div class="span12">
                    <center>
                        <h4 style="text-decoration: underline; color: red; ">Choose Products From Given
                            List</h4>
                    </center>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Company Name</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <!-- <th>Quentity</th> -->
                                <!-- <th>Total</th> -->
                                <th>Add</th>
                                <!-- <th>Delete</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $row): ?>

                                <tr>
                                    <td style="text-align: center;">
                                        <?php echo $row->id; ?>
                                    </td>
                                    <td style="text-align: center;">
                                        <?php echo $row->company_name; ?>
                                    </td>
                                    <td style="text-align: center;">
                                        <?php echo $row->product_name; ?>
                                    </td>
                                    <td style="text-align: center;">
                                        <?php echo $row->price; ?>
                                    </td>
                                    <!-- <td style="text-align: center;" class=" span3">
                                        <input type="number" name="quentity" value="" class=" span4">
                                    </td> -->
                                    <td style="text-align: center;">
                                        <a href="<?php echo base_url('Auth/add/' . $row->id) ?>"
                                            class="btn btn-success btm-sm">Add</a>
                                    </td>

                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>









                    <br><br><br><br>
                </div>
            </div>
            <!-- ---------end new row ---------- -->

            <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
                <div class="span12">
                    <center>
                        <h4 style="text-decoration: underline; color: red; ">
                            <?php echo $this->session->userdata('name'); ?>'s Taken Products
                        </h4>
                        <br>
                    </center>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Company Name</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <!-- <th>Quentity</th> -->
                                <!-- <th>Total</th> -->
                                <!-- <th>Edit</th> -->
                                <th>Delete</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach ($emp_cart as $row): ?>

                                <tr>
                                    <td style="text-align: center;">
                                        <?php echo $row->id; ?>
                                    </td>
                                    <td style="text-align: center;">
                                        <?php echo $row->company_name; ?>
                                    </td>
                                    <td style="text-align: center;">
                                        <?php echo $row->product_name; ?>
                                    </td>
                                    <td style="text-align: center;" names="price">


                                        <?php echo $row->price; ?>


                                    </td>
                                    <!-- <td style="text-align: center;" class="span1">
                                        <input type="number" id="qty" name="qty" onchange="Calc(this);">
                                    </td> -->
                                    <!-- <td style="text-align: center;">
                                        <a href="<?php echo base_url('admin/edit/' . $row->id) ?>"
                                            class="btn btn-success btm-sm">Edit</a>
                                    </td> -->





                                    <td style="text-align: center;">
                                        <a href="<?php echo base_url('Auth/delete_cart/' . $row->id) ?>"
                                            class="btn btn-danger btm-sm" onclick="Calc(this);">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>

                    </table>


                    <!-- 
$this->db->select_sum('age'); -->

                    <h4>




                        <span>Total</span>
                        <input type="text" class="from-control text-end" id="amt" name="amt" placeholder=""
                            value="<?php echo $sum; ?>">

                    </h4>


                    <br><br><br><br>

                    <center>
                        <input type="submit" name="submit1" value="Make Payment " class="btn btn-success">
                    </center>

                </div>
            </div>
        </div>
    </form>

</div>

<script>

    function Calc(v) {
        var index = $(v).parent().parent().index();
        alert("Product Deleted SucessFully");
    }
</script>


<!--end-main-container-part-->
<!--Footer-part-->
<?php
include 'footer.php';
?>