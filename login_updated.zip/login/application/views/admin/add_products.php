<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Side</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/bootstrap-responsive.min.css" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/fullcalendar.css" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/matrix-style.css" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/matrix-media.css" />
    <link href="<?php echo site_url(); ?>assets/resources/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/jquery.gritter.css" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>

<body>

    <div id="header">

        <h2 style="color: white;position: absolute">
            <a href="dashboard.html" style="color:white; margin-left: 30px; margin-top: 40px">Dashboard</a>
        </h2>
    </div>


    <!--top-Header-menu-->
    <div id="user-nav" class="navbar navbar-inverse">
        <ul class="nav">
            <li class="dropdown" id="profile-messages">
                <a title="" href="" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i
                        class="icon icon-user"></i> <span class="text">Welcome :
                        <?php echo $this->session->userdata('name'); ?>
                    </span><b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <!-- <li><a href="../admin/admin.php"><i class="icon-user"></i>Go To Admin</a></li>
                    <li class="divider"></li> -->

                    <li class="divider"></li>

                    <li><a href="<?php echo site_url() ?>Auth"><i class="icon-check"></i> Go To User</a></li>
                    <li class="divider"></li>
                    <li><a href="<?php echo site_url(); ?>Auth/admin_logout"><i class=" icon-key"></i> Logout</a></li>
                </ul>
            </li>


        </ul>
    </div>

    <!--sidebar-menu-->
    <div id="sidebar">
        <ul>
            <li class="active">
                <a href="/login/Auth/add_products"><i class=" icon icon-home"></i><span>Dashboard</span></a>
            </li>

            <li class="submenu"><a href="#"><i class="icon icon-th-list"></i> <span>Forms</span> <span
                        class="label label-important">2</span></a>
                <ul>
                    <!-- <li><a href="add_products.php">Add Products</a></li> -->
                    <li><a href="">Add Products </a></li>
                    <li><a href="<?php echo site_url(); ?>Auth/index">Go To User Login </a></li>
                </ul>
            </li>

        </ul>
    </div>
    <!--sidebar-menu-->
    <div id="search">

        <a href="<?php echo site_url() ?>Auth/admin_logout" style="color:white"><i class="icon icon-share-alt "></i>
            <span>LogOut</span></a>

    </div>





    <!--main-container-part-->
    <div id="content">
        <!--breadcrumbs-->
        <div id="content-header">
            <div id="breadcrumb"><a href="add_products" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
                    Add New Products</a></div>
        </div>
        <!--End-breadcrumbs-->

        <!--Action boxes-->
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span11">
                    <div class="widget-box">
                        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                            <h5>Add New Products</h5>
                        </div>
                        <div class="widget-content nopadding">
                            <!-- <form name="form1" action="" method="post" class="form-horizontal"> -->

                            <section class="form-horizontal">

                                <?php echo form_open('Auth/products'); ?>
                                <div class="control-group">
                                    <label class="control-label">Enter Company Name :</label>
                                    <br>
                                    <div class="controls">
                                        <input type="text" class="span9" id="company_name"
                                            placeholder="Enter Company Name" name="company_name" / required>
                                    </div>
                                </div>


                                <div class="control-group">
                                    <label class="control-label">Enter Product Name :</label>
                                    <br>
                                    <div class="controls">
                                        <input type="text" class="span9" id="product_name"
                                            placeholder="Enter Product name" name="product_name" / required>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Enter Price :</label>
                                    <br>
                                    <div class="controls">
                                        <input type="text" class="span9" id="price" placeholder="Enter Price"
                                            name="price" / required>
                                    </div>
                                </div>





                                <div class="alert alert-danger" id="error" style="display: none">
                                    This Product is already exist ! please try another.
                                </div>

                                <div class="form-actions">
                                    <button type="submit" name="submit1" class="btn btn-success"
                                        onclick="Add(this);">Save</button>
                                </div>

                                <?php echo form_close(); ?>



                                <div class="alert alert-sucess" id="sucess" style="display:none">
                                    Product inserted sucessfully!.
                                </div>


                            </section>
                            <!-- </form> -->
                        </div>
                    </div>

                    <div class="widget-content nopadding">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>Company Name</th>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                    <!-- <th>Packaging Size</th> -->
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($products as $row): ?>

                                    <tr>
                                        <td style="text-align: center;">
                                            <?php echo $row->id; ?>
                                        </td>
                                        <td style="text-align: center;">
                                            <?php echo $row->company_name; ?>
                                        </td>
                                        <td style="text-align: center;">
                                            <?php echo $row->product_name; ?>
                                        </td>
                                        <td style="text-align: center;">
                                            <?php echo $row->price; ?>
                                        </td>
                                        <td style="text-align: center;">
                                            <a href="<?php echo base_url('admin/edit/' . $row->id) ?>"
                                                class="btn btn-success btm-sm">Edit</a>
                                        </td>
                                        <td style="text-align: center;">
                                            <a href="<?php echo base_url('admin/delete/' . $row->id) ?>"
                                                class="btn btn-danger btm-sm" onclick="Delete(this);">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
        </div>

    </div>


    <!--end-main-container-part-->
    <!--Footer-part-->
    <div class="row-fluid">
        <div id="footer" class="span12" style="color:white"> Designed And Developed By: Vishal Shinde</div>
    </div>
    <!--end-Footer-part-->
    <script src="<?php echo site_url(); ?>assets/resources/js/excanvas.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/jquery.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/jquery.ui.custom.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/bootstrap.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/jquery.flot.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/jquery.flot.resize.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/jquery.peity.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/fullcalendar.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/matrix.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/matrix.dashboard.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/jquery.gritter.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/matrix.interface.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/matrix.chat.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/jquery.validate.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/matrix.form_validation.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/jquery.wizard.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/jquery.uniform.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/select2.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/matrix.popover.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo site_url(); ?>assets/resources/js/matrix.tables.js"></script>


    <script type="text/javascript">


        <?php if ($this->session->flashdata('success')) { ?>
            toastr.success("<?php echo $this->session->flashdata('success'); ?>");
        <?php } else if ($this->session->flashdata('wrong')) { ?>
                toastr.error("<?php echo $this->session->flashdata('wrong'); ?>");
        <?php } else if ($this->session->flashdata('warning')) { ?>
                    toastr.warning("<?php echo $this->session->flashdata('warning'); ?>");
        <?php } else if ($this->session->flashdata('info')) { ?>
                        toastr.info("<?php echo $this->session->flashdata('info'); ?>");
        <?php } ?>
        <?php
        $this->session->unset_userdata('success'); ?>

        <?php
        $this->session->unset_userdata('wrong'); ?>

    </script>

    <script>

        function Delete(v) {
            var index = $(v).parent().parent().index();
            alert("Product Deleted successfully");
        }
        function Add(v) {
            var index = $(v).parent().parent().index();
            alert("Product Added successfully");
        }
    </script>

</body>

</html>