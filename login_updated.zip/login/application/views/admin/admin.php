<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Vishal Avinash Shinde">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="This is a login page template based on Bootstrap 5">
    <title>Admin Page</title>
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/all.css">
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/toast/toast.min.css">
    <script src="<?php echo site_url(); ?>assets/toast/jqm.js"></script>
    <script src="<?php echo site_url(); ?>assets/toast/toast.js"></script>

</head>

<body>
    <section class="h-100">
        <div class="container h-100">
            <div class="row justify-content-sm-center h-100">
                <div class="col-xxl-4 col-xl-5 col-lg-5 col-md-7 col-sm-9">
                    <div class="text-center my-5">
                        <img src="<?php echo site_url(); ?>assets/logo.jpg" alt="logo" width="100">
                    </div>
                    <div class="card shadow-lg">
                        <div class="card-body p-5">
                            <h1 class="fs-4 card-title fw-bold mb-4">Admin Login</h1>
                            <?php echo form_open('Auth/admin_login'); ?>
                            <div class="mb-3">
                                <label class="mb-2 text-muted" for="email">E-Mail Address</label>
                                <input id="email" type="email" class="form-control" name="email" value="" required
                                    autofocus>

                            </div>

                            <div class="mb-3">

                                <label class="mb-2 text-muted" for="password">Passsword</label>
                                <input id="password" type="password" class="form-control" name="password" required>

                            </div>

                            <div class="d-flex align-items-center">

                                <button type="submit" class="btn btn-primary ms-auto">
                                    Login
                                </button>
                            </div>
                            <?php echo form_close(); ?>
                        </div>
                        <div class="card-footer py-3 border-0">
                            <div class="text-center">
                                Are You User? <a href="../" class="text-dark">User Login</a>
                            </div>
                        </div>
                    </div>
                    <div class="text-center mt-5 text-muted">
                        Copyright &copy; 2024 &mdash; Designed And Developed By: Vishal Shinde
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script type="text/javascript">


        <?php if ($this->session->flashdata('success')) { ?>
            toastr.success("<?php echo $this->session->flashdata('success'); ?>");
        <?php } else if ($this->session->flashdata('wrong')) { ?>
                toastr.error("<?php echo $this->session->flashdata('wrong'); ?>");
        <?php } else if ($this->session->flashdata('warning')) { ?>
                    toastr.warning("<?php echo $this->session->flashdata('warning'); ?>");
        <?php } else if ($this->session->flashdata('info')) { ?>
                        toastr.info("<?php echo $this->session->flashdata('info'); ?>");
        <?php } ?>
        <?php
        $this->session->unset_userdata('success'); ?>

        <?php
        $this->session->unset_userdata('wrong'); ?>

    </script>
</body>

</html>