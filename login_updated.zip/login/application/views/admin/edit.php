<!DOCTYPE html>
<html lang="en">

<head>
    <title>Update Product</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/bootstrap-responsive.min.css" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/fullcalendar.css" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/matrix-style.css" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/matrix-media.css" />
    <link href="<?php echo site_url(); ?>assets/resources/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/resources/css/jquery.gritter.css" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>

<body>


    <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
            <h5>Update Product</h5>
        </div>
        <div class="widget-content nopadding">
            <form name="form1" action="<?php echo base_url('admin/update/' . $products->id) ?>" method="post"
                class="form-horizontal">

                <section class="form-horizontal">


                    <div class="control-group">
                        <label class="control-label">Update Company Name :</label>
                        <br>
                        <div class="controls">
                            <input type="text" class="span9" id="company_name" value="<?= $products->company_name ?>"
                                placeholder="Enter Company Name" name="company_name" / required>

                        </div>
                    </div>


                    <div class="control-group">
                        <label class="control-label">Update Product Name :</label>
                        <br>
                        <div class="controls">
                            <input type="text" class="span9" id="product_name" value="<?= $products->product_name ?>"
                                placeholder="Enter Product name" name="product_name" / required>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Update Price :</label>
                        <br>
                        <div class="controls">
                            <input type="text" class="span9" id="price" value="<?= $products->price ?>"
                                placeholder="Enter Price" name="price" / required>
                        </div>
                    </div>





                    <div class="alert alert-danger" id="error" style="display: none">
                        This Product is already exist ! please try another.
                    </div>

                    <div class="form-actions">
                        <button type="submit" name="submit1" class="btn btn-success"
                            onclick="Update(this);">Update</button>
                    </div>





                    <div class="alert alert-sucess" id="sucess" style="display:none">
                        Product inserted successfully!.
                    </div>


                </section>
            </form>
        </div>
    </div>

    <script>

        function Update(v) {
            var index = $(v).parent().parent().index();
            alert("Product Updated successfully");
        }
    </script>


</body>

</html>