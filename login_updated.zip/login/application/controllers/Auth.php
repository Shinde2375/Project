<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{


	public function index()
	{
		$this->load->view('Auth/login');
	}
	public function admin_index()
	{
		$this->load->view('admin/admin');
	}


	public function register()
	{
		$this->load->view('Auth/register');
	}

	public function registration_form()
	{
		$this->auth_model->register_user();
	}

	public function login_form()
	{
		$this->auth_model->login_user();
	}
	public function admin_login()
	{


		$this->auth_model->login_admin();
	}
	public function products()
	{
		$this->auth_model->insert_product();


	}

	public function main()
	{
		if ($this->session->userdata('log') != 'logged') {
			redirect('Auth/index');
		}

		$this->load->view('Auth/index');

	}


	public function product_sales()
	{
		if ($this->session->userdata('log') != 'logged') {
			redirect('Auth/index');
		}

		$this->load->model('auth_model');
		// $data['emp_cart'] = $this->auth_model->get_total();
		$data['sum'] = $this->auth_model->get_totalval();

		$data['emp_cart'] = $this->auth_model->get_cart();
		// $this->load->model('auth_model');
		$data['products'] = $this->auth_model->get_product();

		// $this->load->view('admin/add_products', $data);
		$this->load->view('Auth/product_sales', $data);

	}
	public function admin()
	{
		if ($this->session->userdata('logd') != 'loggeds') {
			redirect('Auth/admin_index');
		} else {

			$data['products'] = $this->auth_model->get_product();
			$this->load->view('admin/add_products', $data);
		}

	}
	public function add_products()
	{
		if ($this->session->userdata('logd') != 'loggeds') {
			redirect('Auth/admin_index');
		}

		$this->load->model('auth_model');
		$data['products'] = $this->auth_model->get_product();

		$this->load->view('admin/add_products', $data);
		// redirect(base_url('Auth/add_products'));
	}


	public function edit($id)
	{
		$this->load->model('auth_model');
		$data['products'] = $this->auth_model->editproduct($id);

		$this->load->view('admin/edit', $data);
	}
	public function add($id)
	{
		$this->load->model('auth_model');
		$data['products'] = $this->auth_model->addproduct($id);

		$this->load->view('Auth/add', $data);
	}

	public function update($id)
	{
		$data = [
			'company_name' => $this->input->post('company_name'),
			'product_name' => $this->input->post('product_name'),
			'price' => $this->input->post('price')
		];
		$this->load->model('auth_model');
		$this->auth_model->update_product($data, $id);

		redirect(base_url('Auth/add_products'));
	}
	public function add_product($id)
	{
		$data = [
			'company_name' => $this->input->post('company_name'),
			'product_name' => $this->input->post('product_name'),
			'price' => $this->input->post('price')
		];
		$this->load->model('auth_model');
		$this->auth_model->add_product($data, $id);

		redirect(base_url('Auth/product_sales'));
	}

	public function delete($id)
	{
		$this->load->model('auth_model');
		$this->auth_model->delete_product($id);
		redirect(base_url('Auth/add_products'));
	}
	public function delete_cart($id)
	{
		$this->load->model('auth_model');
		$this->auth_model->delete_cart($id);
		redirect(base_url('Auth/product_sales'));
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('Auth/index');
	}
	public function admin_logout()
	{
		$this->session->sess_destroy();
		redirect('Auth/admin');
	}



}


